# Support

Use GitHub Issues for reproducible installer, Compose, migration-order, backup,
adoption, or Docker-local diagnostic defects. Include Seedbed version, redacted
config digest, exact package coordinates, Docker/Compose versions, operation ID,
and bounded issue codes. Never attach credentials, a token file, database, blob
payload, backup archive, or unredacted diagnostic output.
